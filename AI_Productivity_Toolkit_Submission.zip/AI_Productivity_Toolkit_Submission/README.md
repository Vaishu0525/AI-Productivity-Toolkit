# AI Productivity Toolkit
## Module 2: Prompt Engineering & AI Productivity

### Project overview
This beginner-friendly project demonstrates reusable prompt-engineering templates for common productivity tasks. It includes a Streamlit interface that builds structured prompts for summarization, email drafting, resume editing, sentiment classification, and Python coding assistance.

### Features
- Text summarization prompt builder
- Professional email prompt builder
- Resume improvement prompt builder
- Customer-feedback classification prompt builder
- Python coding/debugging prompt builder
- Zero-shot and few-shot prompt examples
- Prompt template library in JSON
- Structural prompt checklist report in CSV, JSON, and TXT

### Technology
- Python
- Streamlit
- JSON and CSV
- Google Colab / Jupyter Notebook
- GitHub

### Run locally
1. Install Python 3.9 or newer.
2. Open a terminal in this project folder.
3. Install dependencies:
   `pip install -r requirements.txt`
4. Start the app:
   `streamlit run app.py`
5. Open the local URL shown in the terminal (usually http://localhost:8501).

### Important scope note
This version generates structured prompts; it does not connect to an external AI model or automatically generate AI answers. Copy a generated prompt into an AI assistant to obtain a response. The testing report measures the presence of Role, Context, Instruction, and Constraints fields only; it does not measure answer accuracy.

### Project structure
- `app.py` — Streamlit application
- `requirements.txt` — Python dependency list
- `prompts/Prompt_Template_Library.json` — reusable prompt templates
- `testing_reports/` — structural checklist reports
- `notebooks/` — example notebook
- `screenshots/` — add your own screenshots of actual execution

### Screenshots
Add genuine screenshots of your own app and notebook runs to the `screenshots/` folder before submission.

### Author
Vaishnavi E

### Submission reminder
Before submitting, run the app, verify the files, add your actual screenshots, and follow your internship provider's required naming and submission instructions.
