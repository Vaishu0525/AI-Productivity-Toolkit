import json
import streamlit as st

st.set_page_config(page_title="AI Productivity Toolkit", page_icon="🤖", layout="wide")

st.title("🤖 AI Productivity Toolkit")
st.caption("Module 2 | Prompt Engineering & AI Productivity")
st.info(
    "This application builds reusable prompts. Copy a generated prompt into your "
    "preferred AI assistant to obtain an AI-generated response. This version does "
    "not call an external AI model."
)

def make_prompt(role, context, instruction, constraints, examples=None):
    parts = [
        f"ROLE:\n{role}",
        f"CONTEXT:\n{context}",
        f"INSTRUCTION:\n{instruction}",
    ]
    if examples:
        parts.append(f"EXAMPLES:\n{examples}")
    parts.append(f"CONSTRAINTS:\n{constraints}")
    return "\n\n".join(parts)

tool = st.sidebar.selectbox(
    "Choose a tool",
    ["Home", "Text Summarizer", "Email Writer", "Resume Assistant",
     "Text Classifier", "Python Coding Assistant", "Prompt Engineering Examples"]
)

if tool == "Home":
    st.subheader("Welcome")
    st.write("A small toolkit demonstrating reusable prompt-engineering patterns.")
    cols = st.columns(3)
    features = [
        ("Text Summarizer", "Create concise-summary prompts."),
        ("Email Writer", "Draft professional-email prompts."),
        ("Resume Assistant", "Improve resume wording without inventing experience."),
        ("Text Classifier", "Create sentiment-classification prompts."),
        ("Coding Assistant", "Ask for code review and debugging guidance."),
        ("Prompt Examples", "Compare zero-shot and few-shot approaches."),
    ]
    for i, (name, desc) in enumerate(features):
        with cols[i % 3]:
            st.markdown(f"**{name}**")
            st.write(desc)

elif tool == "Text Summarizer":
    st.subheader("Text Summarizer")
    text = st.text_area("Paste the text to summarize", height=180)
    length = st.selectbox("Summary length", ["3 bullet points", "5 bullet points", "One short paragraph"])
    if st.button("Build summarization prompt"):
        if text.strip():
            st.code(make_prompt(
                "Act as a careful professional summarizer.",
                "The user wants to understand the key information quickly.",
                f"Summarize the following text:\n{text}",
                f"Use simple English. Format the result as {length}. Do not add facts not present in the text."
            ), language="text")
        else:
            st.warning("Please enter text first.")

elif tool == "Email Writer":
    st.subheader("Professional Email Writer")
    recipient = st.text_input("Recipient (for example, HR Manager)")
    topic = st.text_input("Email topic")
    purpose = st.text_area("Important details to include", height=100)
    tone = st.selectbox("Tone", ["Professional", "Formal", "Friendly"])
    if st.button("Build email prompt"):
        if recipient.strip() and topic.strip():
            st.code(make_prompt(
                "Act as a professional business communication assistant.",
                f"The email is addressed to: {recipient}.",
                f"Write an email about: {topic}.\nDetails: {purpose}",
                f"Use a {tone.lower()} tone. Include a subject line, greeting, clear body, and polite closing. Do not invent details."
            ), language="text")
        else:
            st.warning("Please enter the recipient and topic.")

elif tool == "Resume Assistant":
    st.subheader("Resume Assistant")
    description = st.text_area("Paste a resume bullet or experience description", height=150)
    target = st.text_input("Target role (optional)")
    if st.button("Build resume-improvement prompt"):
        if description.strip():
            st.code(make_prompt(
                "Act as an ethical resume editor.",
                f"The applicant is applying for: {target or 'an entry-level role'}.",
                f"Improve this resume content:\n{description}",
                "Use concise, professional language and strong action verbs. Preserve the original meaning. Do not invent skills, metrics, employers, or experience."
            ), language="text")
        else:
            st.warning("Please enter resume content.")

elif tool == "Text Classifier":
    st.subheader("Customer Feedback Classifier")
    feedback = st.text_area("Enter customer feedback", height=120)
    if st.button("Build classification prompt"):
        if feedback.strip():
            st.code(make_prompt(
                "Act as a text classification assistant.",
                "The task is to classify customer feedback sentiment.",
                f"Classify this feedback:\n{feedback}",
                'Return valid JSON with exactly these keys: "sentiment" (Positive, Negative, or Neutral) and "reason". Do not include markdown fences.'
            ), language="text")
        else:
            st.warning("Please enter feedback.")

elif tool == "Python Coding Assistant":
    st.subheader("Python Coding Assistant")
    code = st.text_area("Paste Python code", height=180)
    problem = st.text_area("Describe the error or expected behavior", height=100)
    if st.button("Build debugging prompt"):
        if code.strip():
            st.code(make_prompt(
                "Act as an experienced Python programming tutor.",
                "The user is a beginner and wants to understand the solution.",
                f"Review this code:\n{code}\n\nProblem or expected behavior:\n{problem or 'Please inspect the code for likely issues.'}",
                "Identify syntax and likely runtime or logic errors. Explain each issue simply. Provide corrected code and a small test. Do not claim to have executed the code."
            ), language="text")
        else:
            st.warning("Please paste Python code.")

elif tool == "Prompt Engineering Examples":
    st.subheader("Zero-shot vs Few-shot prompting")
    st.markdown("**Zero-shot:** an instruction without examples.")
    st.code(
        "Classify the sentiment as Positive, Negative, or Neutral.\\n"
        "Feedback: The delivery was excellent.",
        language="text"
    )
    st.markdown("**Few-shot:** an instruction supported by examples.")
    st.code(
        "Classify customer feedback.\\n"
        "I love this product. -> Positive\\n"
        "The service was terrible. -> Negative\\n"
        "The product is okay. -> Neutral\\n"
        "Now classify: The delivery was excellent.",
        language="text"
    )

st.sidebar.markdown("---")
st.sidebar.caption("Created as a learning project. Review generated prompts before using them.")
